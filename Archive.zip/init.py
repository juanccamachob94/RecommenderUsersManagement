from clients.client import Client

Client.main()
